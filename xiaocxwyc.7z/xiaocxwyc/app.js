// app.js
App({
  globalData:{
    appsec :null,
    apptoken :null,
  }
})
