
import {Base64, generateSignature, buildURL} from './encode'

const crypto = require('crypto-js');
function generateApp_signature(app_key,secret) {
  function hmacSha256(message, secretKey) {
    const hmac = crypto.HmacSHA256(message, secretKey)
    return hmac.toString();
  }
  const signature = Base64.encode(hmacSha256(app_key, secret))
  //const signature = Base64.encode(hmac.toString());
  return signature;
}

export const get_salelistdetails =({
  params = {},
  params2 ={},
  path = '/jdy/v2/scm/sal_out_bound_detail',
  method = 'GET',
  //app_key = 'xJ2o8BJ6',
 // appSecret = 'ce103553ec930f153f6f01f174fba17b2ddc6a89',
  clientId = '277152',
  apptoken_ ='',
}) => {
  const headers = {
    'x-api-nonce': '1655775240000',
    'x-api-timestamp': Date.now(),
  };
  const clientSecret ='42dbb95549efa327c617250efd39845c';
  const signature = generateSignature(method, path, params2, headers, clientSecret);
  console.log("kehusignature: ", signature);
  const url4 =  buildURL(`https://api.kingdee.com${path}`,params);
  console.log("req_url: ",url4);

  // const apptoken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHQiOnsiYWNjb3VudElkIjoiMTcxNDM4MTA3NzgwMzU1NTg5MCIsImdyb3VwTmFtZSI6Im5zLXQ2OCIsImFwcF9rZXkiOiJ4SjJvOEJKNiIsInRlbmFudElkIjoiNzk4MzY5MTA5ODU0NyIsInVzZXJOYW1lIjoidTEzMzkxNDY1NDg5In0sImdycCI6Im5zLXQ2OCIsImV4cCI6MTcxNjk2MTI0MywiYWlkIjoiMTcxNDM4MTA3NzgwMzU1NTg5MCIsImlhdCI6MTcxNjg3NDg0M30.tLD1FqxxWvGux5-tnx0fNtpD1zhNQUhtmFd5MLyAzDM';
  
  return new Promise((resolve,reject) => {
    var config = {
      method,
      url: url4,
      header: {
        'X-Api-ClientID': clientId,
        'X-Api-Auth-Version': '2.0',
        'X-Api-SignHeaders': 'X-Api-TimeStamp,X-Api-Nonce',
        'Content-Type': 'application/json',
        'X-GW-Router-Addr': 'https://tf.jdy.com/',
        ...Object.entries(headers).reduce((acc, [key, value]) => {
          acc[key.toUpperCase()] = value
          return acc  
        }, {}),
        'X-Api-Signature': signature,
        'app-token':apptoken_,
      },
      success(res) {
        resolve(res)
      },
      fail(err) {
        reject(err)
    },
   }
   wx.request(config)
  })
}