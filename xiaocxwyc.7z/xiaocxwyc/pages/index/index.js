// index.js
import  {request}  from '../../encode'
import {getToken} from '../../getAppToken'
import {order} from '../../testreq'
import {productstorage} from '../../testproductstorage'


// request({
//    method: 'POST',
//    path: '/jdyconnector/app_management/push_app_authorize',
//    params: { outerInstanceId: "267037843258478592" }
// }).then(res => {
//     console.log(res);
// })


getToken({
  method : 'GET',
  path: '/jdyconnector/app_management/kingdee_auth_token',
  params2: {app_key : "xJ2o8BJ6"},
  params :{app_key : "xJ2o8BJ6"},
}).then(res =>{
  console.log(res);
})

order({
   method : 'GET',
   path : '/jdy/v2/bd/customer',
   params2 :{},
   params:{},
}).then(res =>{
  console.log(res);
})


productstorage({
   method : 'GET',
   path : '/jdy/v2/scm/inv_product',
   params2 :{},
   params:{},
}).then(res =>{
  console.log(res);
})


productstorage({
  method : 'GET',
  path : '/jdy/v2/scm/sal_out_bound',
  params2 :{},
  params:{},
}).then(res =>{
 console.log(res);
})



Page({
  data :{
    qrcodeResult:''
  },
  scanQrcode :function(){
    var that  = this;
    wx.scanCode({
      onlyFromCamera:true,
      success : function(res){
        that.setData({
          qrcodeResult :res.result
        })
      }
    })
  }
})
