// index.js
import  {getappSecret}  from '../../encode'
import {getToken} from '../../getAppToken'
//import {order} from '../../'
//import {get_salesoutbondorderlist} from '../../slaesoutbondorderlist'
import {get_salesoutbondorderlist,order} from '../../slaesoutbondorderlist'
import {get_salelistdetails} from '../../salesorderdetails'
import {productstorage} from '../../salesorderdetails'
//import {get_salesoutbondorderlist} from '../../slaesoutbondorderlist.js'

// request({
//    method: 'POST',
//    path: '/jdyconnector/app_management/push_app_authorize',
//    params: { outerInstanceId: "267037843258478592" }
// }).then(res => {
//     console.log(res);
// })


// getToken({
//   method : 'GET',
//   path: '/jdyconnector/app_management/kingdee_auth_token',
//   params2: {app_key : "xJ2o8BJ6"},
//   params :{app_key : "xJ2o8BJ6"},
// }).then(res =>{
//   console.log(res);
// })

Page({
  data :{
     qrcodeResult:'',
     a:'',
     bxx:'',
     c:'',
     d:'',
     e:'',
     f:'',
     g:'',
  },

  
  scanQrcode :  function(){
    var that  = this;
    wx.scanCode({
      onlyFromCamera:true,
      success :  function(res){
     //   ss=  getData()
        that.setData({
          qrcodeResult :res.result, 
     //     bxx : ss
        })
       
      }
    })
    
  },
  
})


async function getData() {
  // 首先调用getEncodeData
  const encodeData = await getappSecret()
  // 这里就能获取到了
  console.log(encodeData);

    const tokenData = await getToken({
       method : 'GET',
       path: '/jdyconnector/app_management/kingdee_auth_token',
      appSecret:encodeData,
       params2: {app_key : "xJ2o8BJ6"},
       params :{app_key : "xJ2o8BJ6"},
       }).then(res =>{
     console.log(res.data);
     console.log(typeof res.data.data);
   //  console.log(Object.values(res.data.data)[3]);  //获取token方式
     return Object.values(res.data.data)[3]
 })
   console.log(tokenData)

        const  list = await order({
            method : 'GET',
            path : '/jdy/v2/scm/sal_out_bound',
            apptoken_ : tokenData,
            }).then(res =>{
                console.log(res.data.data);  
                console.log(typeof res.data.data);
                console.log(typeof res.data.data.rows);
                console.log(res.data.data.rows);
                console.log(typeof res.data.data.rows[0].id);
                //console.log(Object.values(res.data.data)[4]);
                return res.data.data.rows[0].id
         })
         console.log("list: ",list)
 
    
    //获取销售出库单详情
    const orderdetails = await get_salelistdetails({ 
      method : 'GET',
      path: '/jdy/v2/scm/sal_out_bound_detail',
      params2 : {id : list},
      params :{id :list},
      apptoken_ : tokenData        
    }).then(res=>{     
      console.log(res.data.data);
      console.log(typeof res.data.data);
     
    })
  // const list = await get_salesoutbondorderlist(tokenData)
    
  // 后面类似
  // return tokenData;
  //获取id为id_productorder的产品入库单详情
  const id_productorder = '1962301336233967616',
  
  //const id_productorder =  idff,


   id_orderdetails2 = await get_salelistdetails({ 
    method : 'GET',
    path: '/jdy/v2/scm/inv_product_detail',
    params2 : {id : id_productorder},
    params :{id :id_productorder},
    apptoken_ : tokenData        
  }).then(res=>{     
    console.log(res.data.data);
    console.log(typeof res.data.data);
    console.log(res.data.data.material_entity[0].material_id);
    return res.data.data.material_entity[0].material_id;

  })
  

  //获取id为id_product的商品详情
   const idproduct = await get_salelistdetails({ 
    method : 'GET',
    path: '/jdy/v2/bd/material_detail',
    params2 : {id : id_orderdetails2},
    params :{id :id_orderdetails2},
    apptoken_ : tokenData        
  }).then(res=>{     
    console.log(res.data.data);
    console.log(typeof res.data.data);
   // console.log(res.data.data.material_entity[0].material_id);
  //  return res.data.data.material_entity[0].material_id;
    console.log(res.data.data.custom_field);
    
    console.log(Object.values(res.data.data.custom_field)[0]);
    
    //这里返回电机型号到刹车电压
    // return[Object.values(res.data.data.custom_field)[0] , Object.values(res.data.data.custom_field)[1],Object.values(res.data.data.custom_field)[2],Object.values(res.data.data.custom_field)[3],Object.values(res.data.data.custom_field)[4],Object.values(res.data.data.custom_field)[5]];
    
     //这里返回的电机型号
     return Object.values(res.data.data.custom_field)[0] ;

  })
  
  //这里返回的电机型号
  return idproduct;

}

getData()





// order({
//    method : 'GET',
//    path : '/jdy/v2/bd/customer',
//    params2 :{},
//    params:{},
// }).then(res =>{
//   console.log(res);
// })


// productstorage({
//    method : 'GET',
//    path : '/jdy/v2/scm/inv_product',
//    params2 :{},
//    params:{},
// }).then(res =>{
//   console.log(res);
// })


// productstorage({
//   method : 'GET',
//   path : '/jdy/v2/scm/sal_out_bound',
//   params2 :{},
//   params:{},
// }).then(res =>{
//  console.log(res);
// })



// Page({
//   data :{
//     qrcodeResult:''
//   },
//   scanQrcode :function(){
//     var that  = this;
//     wx.scanCode({
//       onlyFromCamera:true,
//       success : function(res){
//         that.setData({
//           qrcodeResult :res.result
//         })
//       }
//     })
//   }
// })
